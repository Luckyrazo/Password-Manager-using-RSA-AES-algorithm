-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2023 at 07:08 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_encrypt`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accdetails`
--

CREATE TABLE `tbl_accdetails` (
  `id` int(100) NOT NULL,
  `acc_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_accdetails`
--

INSERT INTO `tbl_accdetails` (`id`, `acc_name`, `username`, `email`, `password`) VALUES
(1, 'facebook', 'sample', 'samplemail@gmail.com', 0xf4e6f9fd5e470d31a38a3b9d4f6967bd),
(2, 'gmail', 'robert', 'robert@gmail.com', 0x14d079afa8c2de9d3c6a57ce9977ce00),
(22, 'Youtube', 'RIchard', 'Richard@gmail.com', 0x3ea0b50ea0f7e86b0930481e08267067),
(23, 'Facebook', 'facebookme', 'fbme@tyahoo.com', 0x5ded6297c5d4bd1a1f81ee64818cef37),
(27, 'ricky', 'testingmachine', 'Testmeagain@gmail.com', 0x18c124e3ef7bd55d0d54fbf085d4ed1ad726aaea7e61dc8e694abefdafceb053),
(30, 'Yahoo', 'eixch', 'eixchard@yahoo.com', 0xfd41d8281cdd574ac1ff39c2a19f96bda02da178c79c535259c1fbf1fe51daa3333b70844fc4659ba286779a08e960062b4e204508e27f8b658c2f1f8178366812ccc98471e49a81def27c4abd4dad9c),
(38, 'asdfasfd', 'asdf', 'asfd', 0x0107f2892c1c399109e82f662a28c6c0),
(39, 'asdf', 'asdf', 'asdf', 0xc0284f7f31aedd0fe0095981a06659dd);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accdetails`
--
ALTER TABLE `tbl_accdetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accdetails`
--
ALTER TABLE `tbl_accdetails`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
