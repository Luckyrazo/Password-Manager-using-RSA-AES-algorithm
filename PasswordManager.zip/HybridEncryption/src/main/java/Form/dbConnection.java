/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Form;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author lucky
 */
public class dbConnection {
    
   public static String name;
   public static Boolean isClicked =false;
   
    public static Connection con()
    {
       Connection con = null;
          
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_encrypt","root","");
             
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
        
        return con;
        
        
        
        
        
    }
    
    
    
}
