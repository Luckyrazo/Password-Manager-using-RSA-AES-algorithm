/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Form;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Properties;


/**
 *
 * @author lucky
 */
public class login {
    
    public static void main(String[] args) throws NoSuchAlgorithmException, FileNotFoundException, IOException {
   
    // Define a key and its value
    String publicvalue = "ABCEF";
    String privatevalue = "GHIJK";

    // Step 1: Generate a private key
    KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
    keyPairGenerator.initialize(2048); // You can choose the key size
    KeyPair keyPair = keyPairGenerator.generateKeyPair();
    PrivateKey privateKey = keyPair.getPrivate();
    PublicKey publicKey = keyPair.getPublic();

    // Step 2: Save the private key to a file
    byte[] privateKeyBytes = privateKey.getEncoded();
    byte[] publicKeyBytes = publicKey.getEncoded();

    // Specify the properties file path
    String propertiesFilePath = "C:/Users/lucky/OneDrive/Desktop/Encrpting/private_key.txt";

    // Convert the strings to byte arrays
    byte[] privateValueBytes = privatevalue.getBytes();
    byte[] publicValueBytes = publicvalue.getBytes();

    // Store the key-value pairs in the properties file
    storeKeyInPropertiesFile(propertiesFilePath, privateValueBytes, publicValueBytes);

    // Retrieve the key-value pairs from the properties file
    byte[] retrievedPrivateKeyBytes = retrieveKeyFromPropertiesFile(propertiesFilePath, privateValueBytes);
    byte[] retrievedPublicKeyBytes = retrieveKeyFromPropertiesFile(propertiesFilePath, publicValueBytes);

    // Display the retrieved key-value pairs
    String retrievedPrivateValue = new String(retrievedPrivateKeyBytes);
    String retrievedPublicValue = new String(retrievedPublicKeyBytes);
    System.out.println("Retrieved Private Value: " + retrievedPrivateValue);
    System.out.println("Retrieved Public Value: " + retrievedPublicValue);
}

// Method to store key-value pairs in a properties file
private static void storeKeyInPropertiesFile(String filePath, byte[] privateValue, byte[] publicValue) {
    try {
        Properties properties = new Properties();

        // Load the existing properties (if any)
        FileInputStream fileInputStream = new FileInputStream(filePath);
        properties.load(fileInputStream);
        fileInputStream.close();

        // Store the byte arrays as binary data
        properties.put("privateKey", privateValue);
        properties.put("publicKey", publicValue);

        // Save the updated properties to the file
        FileOutputStream fileOutputStream = new FileOutputStream(filePath);
        properties.store(fileOutputStream, null);
        fileOutputStream.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

// Method to retrieve key-value pairs from a properties file
private static byte[] retrieveKeyFromPropertiesFile(String filePath, byte[] keyValue) {
    try {
        Properties properties = new Properties();

        // Load the properties file
        FileInputStream fileInputStream = new FileInputStream(filePath);
        properties.load(fileInputStream);
        fileInputStream.close();

        // Retrieve the value using the provided key
        return (byte[]) properties.get(new String(keyValue));
    } catch (IOException e) {
        e.printStackTrace();
        return null;
    }
}
}
